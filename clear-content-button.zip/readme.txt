=== Clear Content Button ===
Contributors: kraulk
Tags: gutenberg, editor, content, blocks, patterns
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

BETA / EXPERIMENTAL Adds a clear content button to the block editor toolbar that removes text, images, and links while preserving styles.

== Description ==

**This is a beta version - use at your own risk and backup your content before using.**

This plugin adds a "Clear Content" button to the Gutenberg block editor toolbar.
When clicked, it removes all content (text, images, and links) from the selected block and its inner blocks while preserving styles and structure.
Perfect for cleaning up pattern placeholder content!

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/clear-content-button` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the button in the block editor toolbar to clear content from blocks

== Changelog ==

= 0.1 =
* Initial release

== Frequently Asked Questions ==

= What content does this clear? =
The button clears text, images, links, and other content while preserving all styling, layout, and block structure.

= Does it work with nested blocks? =
Yes, when used on a parent block it will clear content from all inner blocks too.