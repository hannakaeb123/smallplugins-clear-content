const { __ } = wp.i18n;
const { BlockControls } = wp.blockEditor;
const { ToolbarGroup, ToolbarButton } = wp.components;
const { createHigherOrderComponent } = wp.compose;
const { Fragment, createElement } = wp.element;

// Custom eraser icon as SVG component
const EraserIcon = () => createElement(
    'svg',
    {
        width: '20',
        height: '20',
        viewBox: '0 0 576 512',
        xmlns: 'http://www.w3.org/2000/svg',
        style: {
            fill: 'currentColor'  // This makes it inherit the color from its parent
        }
    },
    createElement('path', {
        d: 'M290.7 57.4L57.4 290.7c-25 25-25 65.5 0 90.5l80 80c12 12 28.3 18.7 45.3 18.7H288h9.4H512c17.7 0 32-14.3 32-32s-14.3-32-32-32H387.9L518.6 285.3c25-25 25-65.5 0-90.5L381.3 57.4c-25-25-65.5-25-90.5 0zM297.4 416H288l-105.4 0-80-80L227.3 211.3 364.7 348.7 297.4 416z'
    })
);

const withClearContentButton = createHigherOrderComponent((BlockEdit) => {
    return function(props) {
        const { setAttributes, clientId } = props;

        const clearBlockContent = (blockId) => {
            const block = wp.data.select('core/block-editor').getBlock(blockId);

            // Clear current block's content
            const newAttributes = {};
            for (const [key, value] of Object.entries(block.attributes)) {
                // Keep styling and structural attributes
                if (key.includes('style') ||
                    key.includes('align') ||
                    key.includes('className') ||
                    key.includes('anchor') ||
                    key.includes('layout') ||
                    key.includes('level') ||
                    key.includes('tagName') ||
                    key.includes('backgroundColor') ||
                    key.includes('textColor') ||
                    key.includes('gradient') ||
                    key.includes('width') ||
                    key.includes('height') ||
                    key.includes('padding') ||
                    key.includes('margin') ||
                    key.includes('size')) {
                    newAttributes[key] = value;
                }
                // Clear content-related attributes
                else if (key === 'content' ||
                         key === 'text' ||
                         key === 'caption' ||
                         key === 'value' ||
                         key === 'url' ||
                         key === 'href' ||
                         key === 'linkTarget' ||
                         key === 'rel' ||
                         key === 'alt' ||
                         key === 'title' ||
                         key === 'id' && key.includes('image')) {
                    newAttributes[key] = '';
                }
                // Maintain other attributes
                else {
                    newAttributes[key] = value;
                }
            }

            // Update the current block
            wp.data.dispatch('core/block-editor').updateBlockAttributes(blockId, newAttributes);

            // Recursively clear inner blocks
            if (block.innerBlocks && block.innerBlocks.length > 0) {
                block.innerBlocks.forEach(innerBlock => {
                    clearBlockContent(innerBlock.clientId);
                });
            }
        };

        return createElement(
            Fragment,
            null,
            createElement(
                BlockControls,
                { group: "other" },
                createElement(
                    ToolbarGroup,
                    null,
                    createElement(
                        ToolbarButton,
                        {
                            icon: EraserIcon,
                            label: __('Clear Content'),
                            onClick: () => clearBlockContent(clientId)
                        }
                    )
                )
            ),
            createElement(BlockEdit, props)
        );
    };
}, 'withClearContentButton');

wp.hooks.addFilter(
    'editor.BlockEdit',
    'custom-namespace/with-clear-content-button',
    withClearContentButton
);