<?php
/*
Plugin Name: Clear Content Button
Description: Adds a button to the block editor toolbar that clears block content
Version: 0.1
Author: Kristofer Kraul
*/
if (!defined('ABSPATH')) {
    exit;
}

add_action('enqueue_block_editor_assets', function() {
    wp_enqueue_script(
        'clear-content-button',
        plugins_url('js/clear-content-button.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-data', 'wp-compose', 'wp-hooks'),
        '1.0',
        true
    );
});